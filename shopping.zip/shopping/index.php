<?php 
session_start();
require_once "mvc/server.php";
$app = new App();