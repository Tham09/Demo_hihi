<?php 
class auth extends controller{
    function index(){
       echo 'auth';
    }
}