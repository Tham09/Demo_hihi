<?php 
class home extends controller
{
    public $MyModels;
    public $ProductModels;
    function __construct(){
        $this->MyModels             = $this->models('MyModels');
        $this->ProductModels        =  $this->models('ProductModels');

    }
    public function index()
    {
        $product = $this->ProductModels->select_array('*',['publish' => 1],'id desc');
          
        $data = [
            'page'      => 'home/index',
            'product'   => $product
        ];
       $this->viewFrontEnd('frontend/masterlayout',$data);
    }
    function detail($slug){
       $data = $this->ProductModels->select_row('*',['slug' => $slug]);
       if ($data != NULL)
       {
            $cart = $this->cart($data);
       }
    }
}