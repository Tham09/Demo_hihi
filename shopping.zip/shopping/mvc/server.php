<?php
 require_once "./mvc/core/App.php";
 require_once "./mvc/core/controller.php";
 require_once "./mvc/core/db.php";
 require_once "./mvc/core/constant.php";
 require_once "./mvc/helper/JWTOKEN.php";
 require_once "./mvc/config/Router.php";
 require_once "./mvc/config/Routes.php";