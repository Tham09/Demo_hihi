<?php 
define('base_url','http://localhost/shopping/');
define('base_url_admin','http://localhost/shopping/cpanel/');
define('KEYS','ABCXYZ!@#$');