<?php 
class controller 
{
    function view($view,$data=[])
    {
        require_once "./mvc/views/".$view.".php";
    }
    function models($models){
        require_once "./mvc/models/".$models.".php";
        return new $models;
    }
    function helper($helper){
        require_once "./mvc/helper/".$helper.".php";
        return new $helper;
    }
    function viewFrontEnd($view,$data=[])
    {
        foreach($data as $key => $value){
            $$key = $value;
        }
        require_once "./mvc/views/".$view.".php";
    }
   function cart($array){
      
       if (isset($_SESSION['cart']))
       {
           if (array_key_exists($array['id'],$_SESSION['cart']))
           {
                $_SESSION['cart'][$array['id']]['qty'] += 1;
           }
           else
           {
                $_SESSION['cart'][$array['id']] = $array;
                $_SESSION['cart'][$array['id']]['qty'] = 1;
           }
       }
       else
       {
            $_SESSION['cart'][$array['id']] = $array;
            $_SESSION['cart'][$array['id']]['qty'] = 1;
       }
       return $_SESSION['cart'];
   }
}