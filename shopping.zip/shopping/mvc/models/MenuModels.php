<?php 
require_once "./mvc/models/MyModels.php";
class MenuModels extends MyModels{
    protected $table = 'tbl_menu';
}