<?php 
require_once "./mvc/models/MyModels.php";
class PhotoModels extends MyModels{
    protected $table = 'tbl_photo';
}