<?php 
require_once "./mvc/models/MyModels.php";
class CategoryModels extends MyModels{
    protected $table = 'tbl_category';
}