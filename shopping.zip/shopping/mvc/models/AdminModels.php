<?php 
require_once "./mvc/models/MyModels.php";
class AdminModels extends MyModels{
    protected $table = 'tbl_admin';
}