<?php 
require_once "./mvc/models/MyModels.php";
class ProductModels extends MyModels{
    protected $table = 'tbl_product';
}