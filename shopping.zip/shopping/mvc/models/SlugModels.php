<?php 
require_once "./mvc/models/MyModels.php";
class SlugModels extends MyModels{
    protected $table = 'tbl_slug';
}