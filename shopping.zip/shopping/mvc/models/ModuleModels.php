<?php 
require_once "./mvc/models/MyModels.php";
class ModuleModels extends MyModels{
    protected $table = 'tbl_module';
}