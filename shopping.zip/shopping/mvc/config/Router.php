<?php 
$Routes["(:any)"] = 'Route/index/$1';