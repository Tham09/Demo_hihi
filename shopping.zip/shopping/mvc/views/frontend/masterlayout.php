<?php require_once './mvc/views/frontend/includes/header.php' ?>
   <?php require_once './mvc/views/frontend/'.$page.'.php'; ?>
    <!-- footer -->
<?php require_once './mvc/views/frontend/includes/footer.php' ?>
