<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <base href="http://localhost/shopping/">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <link rel="stylesheet" href="public/build/css/shopping.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
</head>
<body>
    <section class="heading">
        <div class="container">
            <div class="row">
                <div class="box">
                    <p>Số điện thoại: <span> <i class="fas fa-phone"></i> <a href="tel:0982824398">0982.824.398</a></span></p>
                </div>
                <div class="box">
                    <div class="button_sign">
                        <a href="" class="register">Đăng ký</a>
                        <a href="" class="login">Đăng nhập</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--  -->
    <section class="name__shop">
        <div class="container">
            <div class="row">
                <div class="box">
                    <a href=""><h3>SHOPPING</h3></a>
                </div>
                <div class="box">
                    <div class="box__search">
                        <input type="search" class="search__input" id="search__input" placeholder="Nhập từ khóa ...">
                        <button id="search"><i class="fas fa-search"></i></button>
                    </div>
                </div>
                <div class="box">
                   <div class="cart">
                        <a href="">
                            <i class="fas fa-shopping-cart"></i>
                            <span>0</span>
                        </a>
                        <div class="list__items_cart">
                            <div class="item">
                                 <div class="image">
                                     <img src="gigabyte-gaming-g5-i5-5s11130sh-191021-102800-600x600.jpg" alt="">
                                 </div>
                                 <div class="name__product">
                                     <p>Laptop Gaming Lorem ipsum dolor sit amet consectetur </p>
                                     <p>300.000 đ</p>
                                 </div>
                                 <div class="quantily">
                                     <i class="fas fa-minus"></i>
                                     <input type="text" value="1" min="1">
                                     <i class="fas fa-plus"></i>
                                 </div>
                                 <div class="btn">
                                     <a href="javascript:void(0)"><i class="fas fa-trash-alt"></i></a>
                                 </div>
                            </div>
                            <div class="item">
                                <div class="image">
                                    <img src="iphone-13-pro-max-silver-600x600.jpg" alt="">
                                </div>
                                <div class="name__product">
                                    <p>Laptop Gaming Lorem ipsum dolor sit amet consectetur </p>
                                    <p>300.000 đ</p>
                                </div>
                                <div class="quantily">
                                    <i class="fas fa-minus"></i>
                                    <input type="text" value="1" min="1">
                                    <i class="fas fa-plus"></i>
                                </div>
                                <div class="btn">
                                    <a href="javascript:void(0)"><i class="fas fa-trash-alt"></i></a>
                                </div>
                           </div>
                         </div>
                   </div>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- nagivation  -->
    <section class="nagivation">
        <div class="container">
            <div class="box menu">
                <nav>
                    <ul>
                        <li><a href="">Trang chủ</a></li>
                        <li><a href="">Hướng dẫn mua hàng</a></li>
                        <li><a href="">Liên hệ</a></li>
                        <li><a href="">Sản phảm</a>
                            <ul class="nav__children">
                                <li><a href="">Iphone</a></li>
                                <li><a href="">Sam Sung</a></li>
                                <li><a href="">Oppo</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="box social">
                <ul>
                    <li><a href=""><i class="fab fa-facebook"></i></a></li>
                    <li><a href=""><i class="fab fa-twitter"></i></a></li>
                    <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                </ul>
            </div>
        </div>
    </section>