<!-- form liên hệ -->
<section class="contact">
    <div class="container">
        <div class="formContact">
            <form action="">
                <div class="input">
                    <div class="title">
                        <label for="">Đăng ký nhận tin</label>
                    </div>
                    <div class="input_enter">
                        <input type="text">
                        <button><i class="fas fa-envelope"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>