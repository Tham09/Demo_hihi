 <!-- slide -->
 <section class="slide">
    <div class="slick_slide">
        <div>
            <img src="public/build/images/slide-1-slider-1.png" alt="">
            <div class="description">
                <a href="">Mua ngay</a>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptate laborum omnis assumenda officiis, 
                </p>
            </div>
        </div>
        <div>
            <img src="public/build/images/slide-1-slider-1.png" alt="">
            <div class="description">
                <a href="">Mua ngay</a>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptate laborum omnis assumenda officiis, 
                </p>
            </div>
        </div>
    </div>
</section>